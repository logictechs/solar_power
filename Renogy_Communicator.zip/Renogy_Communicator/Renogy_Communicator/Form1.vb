Imports System.Text
Imports System.Threading
Imports System.IO
Imports EasyModbus
Imports MQTTnet
Imports MQTTnet.Client
Imports MQTTnet.Client.Options
Imports MQTTnet.Client.Connecting '' Not actually used, for now
Imports MQTTnet.Client.Disconnecting

Public Class Form1
    Dim modbusclient As ModbusClient
    Dim mqttClient As MqttClient
    Dim Factory As MqttFactory = New MqttFactory()
    Dim load_value As String = "0"

    Function Scanports()
        Dim portcounter As Integer = 0
        For Each sp As String In My.Computer.Ports.SerialPortNames
            ports_list_chk_bx.Items.Add(sp)
            ports_list_chk_bx.SetItemChecked(portcounter, True)
            Try
                SerialPort1.PortName = sp
                SerialPort1.Open()
                SerialPort1.Close()
            Catch ex As Exception
                ports_list_chk_bx.SetItemChecked(portcounter, False)
            End Try
            portcounter += 1
        Next
        ports_list_chk_bx.Update()
        Return 0
    End Function

    Async Function Start() As Task
        mqttClient = Factory.CreateMqttClient()
        mqttClient.UseApplicationMessageReceivedHandler(AddressOf MessageRecieved)
        mqttClient.UseDisconnectedHandler(AddressOf ConnectionClosed)

        Dim Options As New MqttClientOptionsBuilder
        With Options
            .WithTcpServer("your_server_here")
            .WithClientId("")
            .WithCredentials("", "")
        End With

        Await mqttClient.ConnectAsync(Options.Build).ConfigureAwait(False)
        Await mqttClient.SubscribeAsync("/load/switch")

    End Function

    Function Publish(Topic As String, Payload As String) As Task
        mqttClient.PublishAsync(Topic, Payload).ConfigureAwait(False)
    End Function

    Function get_values()
        Dim charge_SOC() As Integer = modbusclient.ReadHoldingRegisters(255, 38) 'Charge data values start at 100H but offset by 1 so use ffH or 255
        Dim battery_parameters() As Integer = modbusclient.ReadHoldingRegisters(&HE000, 38) 'Battery parameter data values start at E0001H but offset by 1 so use E000H
        Dim historical_data() As Integer = modbusclient.ReadHoldingRegisters(&HEFFF, 20)

        If modbusclient.Connected And load_value = "1" Then
            modbusclient.WriteSingleRegister(266, 1)
        End If
        If modbusclient.Connected And load_value = "0" Then
            modbusclient.WriteSingleRegister(266, 0)
        End If

        received_values.Rows.Clear()
        For i As Integer = 0 To charge_SOC.GetUpperBound(0)
            Dim x As String() = {i, charge_SOC(i)}
            received_values.Rows.Add(x)
        Next
        battery_parameters_grid.Rows.Clear()
        For i As Integer = 0 To battery_parameters.GetUpperBound(0)
            Dim x As String() = {i + 1, battery_parameters(i)}
            battery_parameters_grid.Rows.Add(x)
        Next
        historical_data_grid.Rows.Clear()
        For i As Integer = 0 To historical_data.GetUpperBound(0)
            Dim x As String() = {i + 1, historical_data(i)}
            historical_data_grid.Rows.Add(x)
        Next

        Publish("/PV/voltage", charge_SOC(7).ToString() * 0.1)
        Publish("/PV/amps", charge_SOC(2).ToString() * 0.01)
        Publish("/Battery/voltage", charge_SOC(1).ToString() * 0.1)
        Publish("/Battery/amps", charge_SOC(5).ToString() * 0.01)
        Return 0
    End Function

    Private Sub MessageRecieved(e As MqttApplicationMessageReceivedEventArgs)
        load_value = Encoding.UTF8.GetString(e.ApplicationMessage.Payload)
    End Sub

    Private Sub ConnectionClosed(e As MqttClientDisconnectedEventArgs)
        MessageBox.Show("MQTT closed")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Scanports()
        Start.GetAwaiter()
    End Sub

    Private Sub rescan_ports_btn_Click(sender As Object, e As EventArgs) Handles rescan_ports_btn.Click
        ports_list_chk_bx.Items.Clear()
        Scanports()
    End Sub

    Private Sub connect_btn_Click(sender As Object, e As EventArgs) Handles connect_btn.Click
        If ports_list_chk_bx.SelectedItems.Count = 0 Then
            MessageBox.Show("Select a port first!")
            Return
        End If
        connect_btn.Enabled = False
        disconnect_btn.Enabled = True
        rescan_ports_btn.Enabled = False

        Try
            modbusclient = New ModbusClient(ports_list_chk_bx.SelectedItem)
            modbusclient.UnitIdentifier = 1
            modbusclient.Baudrate = 9600
            modbusclient.Parity = System.IO.Ports.Parity.None
            modbusclient.StopBits = System.IO.Ports.StopBits.One
            modbusclient.NumberOfRetries = 3
            modbusclient.Connect()

        Catch ex As Exception
            MessageBox.Show("Could not open selected port!")
            connect_btn.Enabled = True
            disconnect_btn.Enabled = False
            rescan_ports_btn.Enabled = True
            Return
        End Try
        get_values_btn.Enabled = True
        auto_get_chk_bx.Enabled = True
        pwr_on_btn.Enabled = True
        pwr_off_btn.Enabled = True
    End Sub

    Private Sub disconnect_btn_Click(sender As Object, e As EventArgs) Handles disconnect_btn.Click
        modbusclient.Disconnect()
        connect_btn.Enabled = True
        disconnect_btn.Enabled = False
        rescan_ports_btn.Enabled = True
        get_values_btn.Enabled = False
        auto_get_chk_bx.Enabled = False
        pwr_on_btn.Enabled = False
        pwr_off_btn.Enabled = False

    End Sub

    Private Sub get_values_btn_Click(sender As Object, e As EventArgs) Handles get_values_btn.Click
        If auto_get_chk_bx.Checked = True Then
            Timer1.Enabled = True
        Else
            Timer1.Enabled = False
        End If
        get_values()
    End Sub

    Private Sub pwr_on_btn_Click(sender As Object, e As EventArgs) Handles pwr_on_btn.Click
        modbusclient.WriteSingleRegister(266, 1)
    End Sub

    Private Sub pwr_off_btn_Click(sender As Object, e As EventArgs) Handles pwr_off_btn.Click
        modbusclient.WriteSingleRegister(266, 0)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        get_values()

    End Sub

    Private Sub auto_get_chk_bx_CheckedChanged(sender As Object, e As EventArgs) Handles auto_get_chk_bx.CheckedChanged


    End Sub
End Class
