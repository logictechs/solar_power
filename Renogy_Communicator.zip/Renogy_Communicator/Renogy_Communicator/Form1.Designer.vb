﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ports_list_chk_bx = New System.Windows.Forms.CheckedListBox()
        Me.connect_btn = New System.Windows.Forms.Button()
        Me.disconnect_btn = New System.Windows.Forms.Button()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.rescan_ports_btn = New System.Windows.Forms.Button()
        Me.get_values_btn = New System.Windows.Forms.Button()
        Me.received_values = New System.Windows.Forms.DataGridView()
        Me.Address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Value = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pwr_on_btn = New System.Windows.Forms.Button()
        Me.pwr_off_btn = New System.Windows.Forms.Button()
        Me.battery_parameters_grid = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.historical_data_grid = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.auto_get_chk_bx = New System.Windows.Forms.CheckBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.received_values, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.battery_parameters_grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.historical_data_grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ports_list_chk_bx
        '
        Me.ports_list_chk_bx.FormattingEnabled = True
        Me.ports_list_chk_bx.Location = New System.Drawing.Point(12, 12)
        Me.ports_list_chk_bx.Name = "ports_list_chk_bx"
        Me.ports_list_chk_bx.Size = New System.Drawing.Size(120, 79)
        Me.ports_list_chk_bx.TabIndex = 0
        '
        'connect_btn
        '
        Me.connect_btn.Location = New System.Drawing.Point(138, 12)
        Me.connect_btn.Name = "connect_btn"
        Me.connect_btn.Size = New System.Drawing.Size(75, 23)
        Me.connect_btn.TabIndex = 1
        Me.connect_btn.Text = "&Connect"
        Me.connect_btn.UseVisualStyleBackColor = True
        '
        'disconnect_btn
        '
        Me.disconnect_btn.Enabled = False
        Me.disconnect_btn.Location = New System.Drawing.Point(138, 41)
        Me.disconnect_btn.Name = "disconnect_btn"
        Me.disconnect_btn.Size = New System.Drawing.Size(75, 23)
        Me.disconnect_btn.TabIndex = 2
        Me.disconnect_btn.Text = "&Disconnect"
        Me.disconnect_btn.UseVisualStyleBackColor = True
        '
        'SerialPort1
        '
        Me.SerialPort1.ReadTimeout = 5000
        '
        'rescan_ports_btn
        '
        Me.rescan_ports_btn.Location = New System.Drawing.Point(138, 70)
        Me.rescan_ports_btn.Name = "rescan_ports_btn"
        Me.rescan_ports_btn.Size = New System.Drawing.Size(75, 23)
        Me.rescan_ports_btn.TabIndex = 3
        Me.rescan_ports_btn.Text = "&Rescan"
        Me.rescan_ports_btn.UseVisualStyleBackColor = True
        '
        'get_values_btn
        '
        Me.get_values_btn.Enabled = False
        Me.get_values_btn.Location = New System.Drawing.Point(219, 41)
        Me.get_values_btn.Name = "get_values_btn"
        Me.get_values_btn.Size = New System.Drawing.Size(75, 23)
        Me.get_values_btn.TabIndex = 4
        Me.get_values_btn.Text = "&Get Values"
        Me.get_values_btn.UseVisualStyleBackColor = True
        '
        'received_values
        '
        Me.received_values.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.received_values.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Address, Me.Value})
        Me.received_values.Location = New System.Drawing.Point(12, 99)
        Me.received_values.Name = "received_values"
        Me.received_values.Size = New System.Drawing.Size(240, 595)
        Me.received_values.TabIndex = 5
        '
        'Address
        '
        Me.Address.HeaderText = "Address"
        Me.Address.Name = "Address"
        '
        'Value
        '
        Me.Value.HeaderText = "Value"
        Me.Value.Name = "Value"
        '
        'pwr_on_btn
        '
        Me.pwr_on_btn.Enabled = False
        Me.pwr_on_btn.Location = New System.Drawing.Point(387, 12)
        Me.pwr_on_btn.Name = "pwr_on_btn"
        Me.pwr_on_btn.Size = New System.Drawing.Size(75, 23)
        Me.pwr_on_btn.TabIndex = 6
        Me.pwr_on_btn.Text = "&Pwr On"
        Me.pwr_on_btn.UseVisualStyleBackColor = True
        '
        'pwr_off_btn
        '
        Me.pwr_off_btn.Enabled = False
        Me.pwr_off_btn.Location = New System.Drawing.Point(387, 41)
        Me.pwr_off_btn.Name = "pwr_off_btn"
        Me.pwr_off_btn.Size = New System.Drawing.Size(75, 23)
        Me.pwr_off_btn.TabIndex = 7
        Me.pwr_off_btn.Text = "Pwr O&ff"
        Me.pwr_off_btn.UseVisualStyleBackColor = True
        '
        'battery_parameters_grid
        '
        Me.battery_parameters_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.battery_parameters_grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn1})
        Me.battery_parameters_grid.Location = New System.Drawing.Point(258, 99)
        Me.battery_parameters_grid.Name = "battery_parameters_grid"
        Me.battery_parameters_grid.Size = New System.Drawing.Size(240, 595)
        Me.battery_parameters_grid.TabIndex = 8
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Address"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'historical_data_grid
        '
        Me.historical_data_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.historical_data_grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.historical_data_grid.Location = New System.Drawing.Point(504, 99)
        Me.historical_data_grid.Name = "historical_data_grid"
        Me.historical_data_grid.Size = New System.Drawing.Size(240, 595)
        Me.historical_data_grid.TabIndex = 9
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Address"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'auto_get_chk_bx
        '
        Me.auto_get_chk_bx.AutoSize = True
        Me.auto_get_chk_bx.Enabled = False
        Me.auto_get_chk_bx.Location = New System.Drawing.Point(300, 45)
        Me.auto_get_chk_bx.Name = "auto_get_chk_bx"
        Me.auto_get_chk_bx.Size = New System.Drawing.Size(68, 17)
        Me.auto_get_chk_bx.TabIndex = 10
        Me.auto_get_chk_bx.Text = "Auto-Get"
        Me.auto_get_chk_bx.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 706)
        Me.Controls.Add(Me.auto_get_chk_bx)
        Me.Controls.Add(Me.historical_data_grid)
        Me.Controls.Add(Me.battery_parameters_grid)
        Me.Controls.Add(Me.pwr_off_btn)
        Me.Controls.Add(Me.pwr_on_btn)
        Me.Controls.Add(Me.received_values)
        Me.Controls.Add(Me.get_values_btn)
        Me.Controls.Add(Me.rescan_ports_btn)
        Me.Controls.Add(Me.disconnect_btn)
        Me.Controls.Add(Me.connect_btn)
        Me.Controls.Add(Me.ports_list_chk_bx)
        Me.Name = "Form1"
        Me.Text = "Renogy Communicator"
        CType(Me.received_values, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.battery_parameters_grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.historical_data_grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ports_list_chk_bx As CheckedListBox
    Friend WithEvents connect_btn As Button
    Friend WithEvents disconnect_btn As Button
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents rescan_ports_btn As Button
    Friend WithEvents get_values_btn As Button
    Friend WithEvents received_values As DataGridView
    Friend WithEvents pwr_on_btn As Button
    Friend WithEvents pwr_off_btn As Button
    Friend WithEvents battery_parameters_grid As DataGridView
    Friend WithEvents Address As DataGridViewTextBoxColumn
    Friend WithEvents Value As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents historical_data_grid As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents auto_get_chk_bx As CheckBox
    Friend WithEvents Timer1 As Timer
End Class
